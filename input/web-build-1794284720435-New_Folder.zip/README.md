# Hotspot Keeper

热点管家 — 监控手机热点，阻止空闲自动关闭，列出已连接设备，掉线时通知你。

An Android app that watches your phone's Wi-Fi tethering hotspot, tries to stop the system from switching it off when idle, lists the devices connected to it, and notifies you when it drops.

It is a monitor, not a controller. Android gives third-party apps no way to turn tethering on or off — see [Android platform limitations](#android-platform-limitations).

## Screenshot

![Hotspot Keeper main screen](docs/screenshot.png)

## Features

- **Status dial** — hotspot on/off, session uptime, and connected-client count in a single Canvas-drawn ring.
- **Keep-alive switch** — starts a foreground watchdog service that polls hotspot state every 15 s.
- **Drop notification** — when the hotspot goes from up to down, a heads-up notification fires on a dedicated high-importance channel, and one tap deep-links into the system tethering settings screen.
- **Device list** — one row per discovered client with its IP and an online/offline pill. Devices that go offline stay in the list, greyed out.
- **Manual device naming** — tap a row to rename it. Names persist in `SharedPreferences` and are keyed to the client's IP.
- **Event timeline** — the 12 most recent events on screen. The buffer is in-memory only: it holds 50 entries and is lost when the process is killed. Two kinds are currently recorded, hotspot started and hotspot dropped.
- **Idle-timeout disable** — with `WRITE_SECURE_SETTINGS` granted over adb, the app writes `0` to four soft-AP auto-shutdown keys in `Settings.Global` at startup. Without the grant, it degrades to notify-only.
- **Session traffic tile** — whole-device bytes since the hotspot was first observed up. Labelled "Device total traffic" because that is what it is; it is not tethered throughput.
- **Runtime language switch** — Auto / EN / 中文, applied instantly without recreating the activity (the target device is Android 12, which predates per-app locales).

Kotlin, Jetpack Compose, Material3, dark theme only. No database, no DI, no network calls off-device — state is one singleton holding a `MutableStateFlow`.

## How it works

**Hotspot detection.** No root, no shell, no reflection, and no reads under `/proc` or `/sys`. `HotspotProbe.findActiveAp()` enumerates `java.net.NetworkInterface.getNetworkInterfaces()` — that goes through netlink rather than the filesystem, so SELinux permits it for an ordinary app. An interface counts as the AP only if **both** hold:

1. its name matches one of `^p2p\d+$`, `^wlan[1-9]$`, `^ap\d*$`, `^softap\d*$`, `^ap_br_wlan\d+$`, and
2. it holds an IPv4 address in `192.168.42.x`–`192.168.50.x`, the AOSP `legacyDhcpRanges` band.

`p2p\d+` is in the list because some EMUI builds tether on `p2p0` rather than the AOSP-conventional `wlan1`/`ap0`. Note the patterns are tested with `any {}` inside a loop over interfaces, so list order does not set priority — whichever matching interface the kernel enumerates first wins.

Both conditions are required because `p2p0` exists whether or not the hotspot is up — it just has no IPv4 address when it is down. Two consequences: a hotspot addressed outside that range (some OEMs use `192.168.137.x`) is not detected at all, and a Wi-Fi Direct group on the conventional `192.168.49.1` would be misreported as an active hotspot.

**Client discovery.** There is no lease table an app can read, so `scanClients()` sweeps the subnet: it takes the AP's own address, derives the `/24`, and launches 253 coroutines on `Dispatchers.IO` calling `InetAddress.isReachable(600)` — ICMP where the kernel allows it, TCP port 7 otherwise. `Dispatchers.IO` caps parallelism at 64 threads and `isReachable` blocks, so this runs as roughly four waves of 64 rather than all at once; a sweep takes about 1–2 s. A client that drops ICMP and refuses TCP/7 is invisible to this method.

The sweep runs from two places: the watchdog service every 15 s, and — while the UI is open — `MainActivity`'s poll loop every 10 s.

**Keeping the hotspot alive.** `IdleTimeoutController.disable()` writes `0` to four candidate keys — `soft_ap_timeout_enabled` (AOSP) plus three vendor spellings — ignoring individual failures. Read-back verification only covers the AOSP key, so the in-app checkmark means "the write did not throw", not "the setting is confirmed off". The value is written once and takes effect at the system level, which is why it survives the app being frozen or killed later.

**Watchdog.** A `connectedDevice` foreground service, `START_STICKY`, one silent ongoing notification. Every 15 s it re-probes, edge-detects up/down transitions, re-runs the client sweep while up, and rewrites its notification. It does **not** restart the hotspot on a drop; it cannot.

## Android platform limitations

This section is the honest part. Everything here was verified against SELinux denials in logcat on a real device, not inferred from `adb shell` (which runs in a different SELinux domain and proves nothing about app access).

- **Apps cannot turn the hotspot on or off.** `TETHER_PRIVILEGED` is `signature|privileged` with no `development` flag, so it cannot even be adb-granted, and there is no public API. `cmd wifi start-softap` says in its own help text that it does not activate internet tethering. The app deep-links you to the settings screen instead, trying `TetherSettings` → `ACTION_WIRELESS_SETTINGS` → `ACTION_SETTINGS` and using the first one that resolves.
- **`dumpsys tethering` is permission-denied to apps**, so the authoritative tether state and DHCP lease list are unreachable. Hence the interface-name + address-range heuristic above.
- **`/proc/net/arp`, `/proc/net/dev`, `/proc/net/route` and `/sys/class/net/*/statistics/` are SELinux-denied** to `untrusted_app`. No MAC addresses, no interface counters.
- **Clients are identified by IP only.** With no ARP table and no useful reverse lookups, `ClientDevice.mac` actually holds the IP string and is used as the identity key everywhere — including the `SharedPreferences` key for custom names. That is why the rename dialog warns that a DHCP reassignment breaks the name mapping, and why the app tells you to set a static IP or DHCP reservation on any client whose name should stick. (MACs would not have helped much anyway: modern clients present randomized ones.)
- **Auto-detected device names and type icons are not implemented.** With no hostname source, every device resolves to the "unknown" icon unless you name it yourself.
- **Per-device traffic is not implemented, deliberately.** `TrafficStats` has no per-peer breakdown, and on the target device the tethering BPF stats maps failed to enumerate (`EBADF`) even for the platform's own `dumpsys`. There is no non-root data source, so every device row shows a dimmed `—` rather than a fabricated `0`.
- **`TrafficStats` cannot isolate forwarded bytes** from the phone's own traffic, so the traffic tile reports a whole-device delta against a session baseline and is labelled accordingly.
- **OEM power managers freeze the process a few seconds after screen-off**, severing sockets, even with a foreground service running. Polling and client scanning stop while the screen is off and resume in the foreground — so a drop that happens with the screen off is typically reported when you next wake the phone, not at the moment it happens. The one-time settings write is unaffected; that asymmetry is why the settings write is the durable fix and the watchdog is the fallback. If this matters to you, whitelist the app in battery optimisation and in your vendor's app-launch manager by hand — the app does not request either.
- **No per-app locale before Android 13**, so the language switch is hand-rolled with `createConfigurationContext` + `CompositionLocalProvider` over `LocalContext`/`LocalConfiguration`. Its scope is the Compose tree only — notification text and the launcher label still follow the system locale.

## Optional setup: WRITE_SECURE_SETTINGS

Granting this one permission over adb is what lets the app disable the soft-AP idle timeout. It is a one-time grant and it survives reboot; no root and no persistently running helper service.

```
adb shell pm grant com.xin.hotspot android.permission.WRITE_SECURE_SETTINGS
```

The app displays this command on screen whenever the permission is missing.

**Without the grant the app is notify-only, and only while it is awake.** Drop detection lives entirely in the watchdog service, so the Keep-alive switch has to be on; and because OEM power managers freeze the process after screen-off, drops are often surfaced when you next unlock rather than as they happen. It cannot prevent the hotspot from auto-shutting-off on idle.

If you want to apply or revert the setting directly instead:

```
# apply
adb shell settings put global soft_ap_timeout_enabled 0

# full revert — the app writes four keys, so restoring only the AOSP one
# leaves the three vendor keys pinned at 0
for k in soft_ap_timeout_enabled hw_softap_timeout_enabled \
         softap_auto_shutdown_enabled wifi_ap_auto_shutdown; do
  adb shell settings delete global $k
done

# the permission check writes a scratch key; nulling it may leave an empty row
adb shell settings delete global hotspot_perm_probe
```

No guarantee your OEM's Wi-Fi stack reads this key at all; some vendors keep the value in `WifiConfigStoreSoftAp.xml`, which is not readable without root. Validate empirically: turn the hotspot on, connect nothing, and check it is still up 15–30 minutes later.

## Build

| | |
|---|---|
| minSdk / targetSdk / compileSdk | 29 / 34 / 35 |
| JDK | 17 (pinned via `jvmToolchain(17)`) |
| Kotlin | 2.0.21 (K2 Compose compiler plugin) |
| AGP / Gradle | 8.7.3 / 8.11.1 |
| Compose BOM | 2024.12.01 |

```
./gradlew assembleDebug
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

Release builds are unsigned unless you supply a keystore. Set `HOTSPOT_STORE_FILE`, `HOTSPOT_STORE_PASSWORD`, `HOTSPOT_KEY_ALIAS` and `HOTSPOT_KEY_PASSWORD` in `~/.gradle/gradle.properties` (never in the repo) to sign one. Minification is off in both build types; this is a sideload build, not a Play Store artifact.

A debug build's first cold start can stall for up to a minute while ART verifies unoptimized Compose dex. That is a one-time debug-build cost, not a deadlock.

## Project layout

```
app/src/main/java/com/xin/hotspot/
├── MainActivity.kt                 Compose entry, 1 s state poll + 10 s subnet sweep, language state
├── data/
│   ├── HotspotProbe.kt             Interface enumeration, AP detection, 253-host sweep, TrafficStats
│   ├── HotspotRepository.kt        Singleton StateFlow, client diffing, event buffer, prefs
│   ├── IdleTimeoutController.kt    WRITE_SECURE_SETTINGS probe, four-key idle-timeout write
│   └── Models.kt                   ClientDevice, HotspotEvent, EventType, HotspotState, HotspotUiState
├── service/
│   └── HotspotWatchdogService.kt   Foreground service, 15 s loop, edge detection, notifications
└── ui/
    ├── HomeScreen.kt               Watchdog card, stat tiles, device list, timeline, language switch
    ├── StatusDial.kt               Canvas status ring: state colour, uptime, client count
    ├── DeviceRow.kt                Client card, online/offline pill, rename dialog
    ├── Localization.kt             createConfigurationContext locale override for the Compose tree
    └── theme/
        └── Theme.kt                Material3 dark colour scheme (dark only, unconditionally)

scripts/
├── detect-device.sh                adb probe: vendor ROM, interface names, readability checks
└── watch-hotspot.sh                Long-run liveness poll, captures logcat at the moment of a drop
```

## Known issues

- `MainActivity` and the watchdog service each keep their own traffic baseline and both write the same state field, so with the watchdog on and the UI open the traffic tile flickers between two values.
- The UI poll loop is not lifecycle-gated: it keeps sweeping the subnet while the activity is merely backgrounded.
- Several UI paths are unreachable in the current build: the amber "recovering" state is never assigned, five of the seven event types are never emitted, and per-device rate and sparkline fields are never written.
- The app does not auto-start on boot.

## License

MIT — see [LICENSE](LICENSE).
