#!/usr/bin/env bash
# 热点常亮实验 —— 开着热点不连任何设备，看它能活多久
#
# 目的: 验证 soft_ap_timeout_enabled=0 是否真的阻止了华为的闲置自动关闭
# 用法: bash scripts/watch-hotspot.sh
# 停止: Ctrl-C

LOG="$(dirname "$0")/../research/hotspot-watch-$(date +%Y%m%d-%H%M%S).log"
mkdir -p "$(dirname "$LOG")"

exec > >(tee -a "$LOG") 2>&1

echo "=========================================="
echo " 热点常亮实验"
echo " 开始时间: $(date '+%Y-%m-%d %H:%M:%S')"
echo " 日志: $LOG"
echo "=========================================="
echo
echo "soft_ap_timeout_enabled = $(adb shell settings get global soft_ap_timeout_enabled 2>/dev/null | tr -d '\r')"
echo "hw_wifi_ap_band         = $(adb shell settings get global hw_wifi_ap_band 2>/dev/null | tr -d '\r')"
echo
echo "时间     | 状态       | 接口          | 客户端 | 备注"
echo "---------|------------|---------------|--------|------------------"

START=$(date +%s)
PREV_STATE=""
DOWN_REPORTED=0

while true; do
  NOW=$(date '+%H:%M:%S')
  ELAPSED=$(( ($(date +%s) - START) / 60 ))

  # 热点接口是否存在（最可靠的"热点开着"判据）
  IFACE=$(adb shell "ls /sys/class/net/ 2>/dev/null" 2>/dev/null | tr -d '\r' | tr ' ' '\n' | grep -E "^(p2p[0-9]+|wlan[1-9]|ap[0-9]*|softap[0-9]*|ap_br_wlan[0-9]+)$" | head -1)

  # tethering 状态
  TETHER=$(adb shell "dumpsys tethering 2>/dev/null | grep -A3 'Tether state'" 2>/dev/null | tr -d '\r' | grep -oE "(Available|Tethered|Unavailable)State" | head -1)

  # 连接的客户端数（ARP 表里非网关的条目）
  CLIENTS=$(adb shell "cat /proc/net/arp 2>/dev/null" 2>/dev/null | tr -d '\r' | tail -n +2 | grep -vE "00:00:00:00:00:00" | grep -cE "^192\.168\.(4[2-9]|50)\." )

  if [ -n "$IFACE" ]; then
    STATE="🟢 开着"
    DOWN_REPORTED=0
  else
    STATE="🔴 关了"
  fi

  NOTE=""
  if [ "$STATE" != "$PREV_STATE" ] && [ -n "$PREV_STATE" ]; then
    NOTE="★ 状态变化! (第${ELAPSED}分钟)"
    if [ "$STATE" = "🔴 关了" ] && [ "$DOWN_REPORTED" = "0" ]; then
      NOTE="$NOTE ← 掉线了，正在抓日志"
      DOWN_REPORTED=1
      echo
      echo "### 掉线时刻的系统日志 ($(date '+%H:%M:%S'), 运行了 ${ELAPSED} 分钟) ###"
      adb logcat -d -t 300 2>/dev/null | grep -iE "softap|hostapd|tether|WifiApConfig|SoftApManager|ap_shutdown|idle" | tail -30
      echo "### 日志结束 ###"
      echo
    fi
  fi
  PREV_STATE="$STATE"

  printf "%s | %-10s | %-13s | %-6s | %s (%dmin)\n" \
    "$NOW" "$STATE" "${IFACE:-—}" "${CLIENTS:-0}" "$NOTE" "$ELAPSED"

  sleep 30
done
