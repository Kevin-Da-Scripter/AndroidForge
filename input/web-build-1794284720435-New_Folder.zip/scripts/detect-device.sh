#!/usr/bin/env bash
# 检测这台手机到底是什么系统 —— 决定整个项目的技术路线
# 用法: bash scripts/detect-device.sh

echo "=========================================="
echo " 设备检测"
echo "=========================================="
echo

echo "--- 1. adb 能不能看到设备 ---"
adb devices -l
echo

DEVCOUNT=$(adb devices | grep -cw "device$")
if [ "$DEVCOUNT" -eq 0 ]; then
  echo "❌ adb 没看到任何已授权设备。"
  echo
  echo "可能原因："
  echo "  a) 手机上还没点「允许 USB 调试」的弹窗 —— 看下手机屏幕"
  echo "  b) 开发者模式/USB调试没开"
  echo "  c) 数据线是只能充电的线，换一根"
  echo "  d) ★ 这是纯血鸿蒙 HarmonyOS NEXT —— 它不用 adb，用华为的 hdc"
  echo
  echo "如果 adb devices 里有设备但状态是 unauthorized，看手机屏幕点允许。"
  exit 1
fi

echo "✅ adb 认得这台手机 —— 说明底层是 Android（鸿蒙4.x / MagicOS / 或原生安卓）"
echo "   纯血鸿蒙 NEXT 是不认 adb 的，所以这条已经排除了最坏情况。"
echo

echo "--- 2. 系统身份 ---"
for p in ro.product.manufacturer ro.product.brand ro.product.model \
         ro.build.version.release ro.build.version.sdk \
         ro.build.version.emui ro.build.version.magic ro.build.display.id \
         ro.build.version.opporom ro.miui.ui.version.name \
         ro.huawei.build.display.id hw_sc.build.platform.version; do
  V=$(adb shell getprop $p 2>/dev/null | tr -d '\r')
  [ -n "$V" ] && printf "  %-38s %s\n" "$p" "$V"
done
echo

echo "--- 3. 鸿蒙/HarmonyOS 相关标记 ---"
adb shell getprop 2>/dev/null | grep -iE "harmony|ohos|hw_sc" | head -20 || echo "  (无 —— 更像是原生安卓或非华为系)"
echo

echo "--- 4. 热点自动关闭超时设置（这是掉线头号嫌疑）---"
for k in soft_ap_timeout_enabled tether_offload_disabled wifi_off_timeout; do
  V=$(adb shell settings get global $k 2>/dev/null | tr -d '\r')
  printf "  %-30s %s\n" "$k" "${V:-<读不到>}"
done
echo "  说明: soft_ap_timeout_enabled = 1 表示「没设备连接时自动关热点」是开着的"
echo

echo "--- 5. 网络接口（找热点用的那个 ap 接口）---"
adb shell ip -o link show 2>/dev/null | tr -d '\r' | awk '{print "  "$2" "$9}' || echo "  读不到"
echo

echo "--- 6. 关键文件可读性测试（决定能不能列出连接的设备）---"
printf "  /proc/net/arp        : "
adb shell "cat /proc/net/arp 2>&1 | head -3" 2>/dev/null | tr -d '\r' | head -3 || echo "读不到"
echo

echo "--- 7. 当前热点状态 ---"
adb shell dumpsys wifi 2>/dev/null | grep -iE "softap|tether|ap state" | head -10 | tr -d '\r' || echo "  读不到"
echo

echo "=========================================="
echo " 检测完成 —— 以上输出可用于排查热点探测问题"
echo "=========================================="
