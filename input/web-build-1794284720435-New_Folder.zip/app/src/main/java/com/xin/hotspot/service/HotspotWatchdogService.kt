package com.xin.hotspot.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.xin.hotspot.MainActivity
import com.xin.hotspot.R
import com.xin.hotspot.data.*
import kotlinx.coroutines.*

/**
 * 热点看门狗前台服务。
 *
 * 职责：
 *  1. 每 15 秒探测一次热点还在不在
 *  2. 掉了就记录事件，并尝试恢复（能做到什么程度取决于权限）
 *  3. 采样流量，累计用量
 *  4. 常驻通知栏，防止被系统杀掉
 *
 * ⚠️ 诚实说明：非 root 的第三方 App 无法直接重新打开「共享移动数据」的热点
 * （TETHER_PRIVILEGED 是 signature|privileged，没有 development 标志，拿不到）。
 * 所以「自动恢复」的实际含义是：
 *  - 有 WRITE_SECURE_SETTINGS：预防性地关掉自动超时，让它压根不会自己关（治本）
 *  - 没有权限：检测到掉线后发通知提醒用户，并记录时间点（治标）
 */
class HotspotWatchdogService : Service() {

    companion object {
        private const val TAG = "Watchdog"
        private const val CHANNEL_ID = "hotspot_watchdog"
        /** 掉线告警单独一个高优先级渠道 —— 常驻通知那个是 IMPORTANCE_LOW，
         *  API 26+ 渠道重要性覆盖 setPriority，共用渠道会导致告警静默。 */
        private const val CHANNEL_ID_ALERT = "hotspot_drop_alert"
        private const val NOTIF_ID = 1001
        private const val POLL_INTERVAL_MS = 15_000L

        const val ACTION_START = "com.xin.hotspot.START_WATCHDOG"
        const val ACTION_STOP = "com.xin.hotspot.STOP_WATCHDOG"

        fun start(ctx: Context) {
            val i = Intent(ctx, HotspotWatchdogService::class.java).setAction(ACTION_START)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                ctx.startForegroundService(i)
            } else {
                ctx.startService(i)
            }
        }

        fun stop(ctx: Context) {
            ctx.startService(
                Intent(ctx, HotspotWatchdogService::class.java).setAction(ACTION_STOP)
            )
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            else -> {
                startForeground(
                    NOTIF_ID,
                    buildNotification(
                        getString(R.string.notif_guarding_title),
                        getString(R.string.notif_guarding_text)
                    )
                )
                startLoop()
            }
        }
        // START_STICKY: 被系统杀掉后尽量重启
        return START_STICKY
    }

    private fun startLoop() {
        if (job?.isActive == true) return
        job = scope.launch {
            // null = 还没探测过。用三态避免「启动时热点本来就开着」被误判成一次开启事件。
            var wasOn: Boolean? = null
            var baseline = 0L

            while (isActive) {
                val ap = HotspotProbe.findActiveAp()
                val isOn = ap != null

                // 同步全局状态 —— 否则 Activity 销毁后 sessionStartAt 会卡在旧值，
                // 常驻通知里的运行时长会跨掉线一直累加。
                HotspotRepository.setHotspotState(
                    if (isOn) HotspotState.ON else HotspotState.OFF
                )

                // 状态变化检测（首轮只记录基线状态，不产生事件）
                if (wasOn == true && !isOn) {
                    Log.w(TAG, "检测到热点掉线")
                    HotspotRepository.recordEvent(
                        EventType.DROPPED,
                        getString(R.string.event_detail_watchdog)
                    )
                    notifyDropped()
                    baseline = 0L
                } else if (wasOn == false && isOn) {
                    Log.i(TAG, "热点已开启，接口=${ap?.iface}")
                    HotspotRepository.recordEvent(EventType.STARTED, ap?.iface ?: "")
                }
                wasOn = isOn

                if (ap != null) {
                    // 流量：只能拿整机计数做差值
                    val now = HotspotProbe.totalBytes()
                    if (baseline == 0L) baseline = now
                    HotspotRepository.setSessionBytes(now - baseline)

                    val clients = HotspotProbe.scanClients(ap.localIp)
                    HotspotRepository.updateClients(clients)

                    updateNotification(
                        getString(R.string.notif_running_title),
                        resources.getQuantityString(
                            R.plurals.notif_running_text,
                            clients.size,
                            clients.size,
                            HotspotRepository.uptimeText()
                        )
                    )
                } else {
                    updateNotification(
                        getString(R.string.notif_off_title),
                        getString(R.string.notif_off_text)
                    )
                }

                delay(POLL_INTERVAL_MS)
            }
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            val ongoing = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notif_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notif_channel_desc)
                setShowBadge(false)
            }
            // 掉线告警要能弹横幅 + 响铃，必须是独立的 HIGH 渠道
            val alert = NotificationChannel(
                CHANNEL_ID_ALERT,
                getString(R.string.notif_alert_channel_name),
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = getString(R.string.notif_alert_channel_desc)
            }
            nm.createNotificationChannel(ongoing)
            nm.createNotificationChannel(alert)
        }
    }

    private fun buildNotification(title: String, text: String): Notification {
        val pi = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentIntent(pi)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setSilent(true)
            .build()
    }

    private fun updateNotification(title: String, text: String) {
        runCatching {
            getSystemService(NotificationManager::class.java)
                .notify(NOTIF_ID, buildNotification(title, text))
        }
    }

    /**
     * 热点设置页的跳转 Intent。
     * AOSP 的 TetherSettings 组件在部分 OEM ROM 上被改名或删掉了，
     * 所以要先 resolve 一遍，解析不到就退回系统设置页 —— 否则点通知没反应。
     */
    private fun tetherSettingsIntent(): Intent {
        val candidates = listOf(
            Intent().setClassName(
                "com.android.settings",
                "com.android.settings.TetherSettings"
            ),
            Intent(android.provider.Settings.ACTION_WIRELESS_SETTINGS),
            Intent(android.provider.Settings.ACTION_SETTINGS),
        )
        return candidates.firstOrNull {
            it.resolveActivity(packageManager) != null
        } ?: candidates.last()
    }

    private fun notifyDropped() {
        runCatching {
            val n = NotificationCompat.Builder(this, CHANNEL_ID_ALERT)
                .setContentTitle(getString(R.string.notif_dropped_title))
                .setContentText(getString(R.string.notif_dropped_text))
                .setSmallIcon(android.R.drawable.stat_sys_warning)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_ERROR)
                .setAutoCancel(true)
                .setContentIntent(
                    PendingIntent.getActivity(
                        this, 1,
                        tetherSettingsIntent(),
                        PendingIntent.FLAG_IMMUTABLE
                    )
                )
                .build()
            getSystemService(NotificationManager::class.java).notify(NOTIF_ID + 1, n)
        }
    }

    override fun onDestroy() {
        job?.cancel()
        scope.cancel()
        super.onDestroy()
    }
}
