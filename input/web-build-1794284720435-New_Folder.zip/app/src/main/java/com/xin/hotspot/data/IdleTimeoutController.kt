package com.xin.hotspot.data

import android.content.Context
import android.provider.Settings
import android.util.Log

/**
 * 「无设备连接时自动关闭热点」的开关控制。
 *
 * 这是解决「热点自己关掉」的核心 —— 用户要的是随身 WiFi 那种常亮效果。
 *
 * 需要 WRITE_SECURE_SETTINGS 权限，通过 adb 一次性授予：
 *   adb shell pm grant com.xin.hotspot android.permission.WRITE_SECURE_SETTINGS
 *
 * 实测（JLN-AL00 / EMUI 14 / Android 12）该权限的保护级别是：
 *   prot=signature|privileged|development
 * 带 development 标志 => 可以用 adb grant 给普通 App，且重启后依然有效。
 */
object IdleTimeoutController {

    private const val TAG = "IdleTimeout"

    /** AOSP 标准键 */
    private const val KEY_AOSP = "soft_ap_timeout_enabled"

    /** 权限探测用的临时键 */
    private const val KEY_PROBE = "hotspot_perm_probe"

    /**
     * 华为可能用的私有键。实测该机 settings 表里没有这些键，
     * 说明要么华为读 AOSP 键，要么用了配置文件（WifiConfigStoreSoftAp.xml，需 root 读）。
     * 这里全部尝试写入，多写几个不会有副作用。
     */
    private val KEYS_TRY = listOf(
        KEY_AOSP,
        "hw_softap_timeout_enabled",
        "softap_auto_shutdown_enabled",
        "wifi_ap_auto_shutdown",
    )

    /**
     * 有没有权限改。
     *
     * 写一个本 App 自己的探测键并读回验证，随后立刻清空。
     * 注意：Settings.Global 没有公开的删除 API，putString(key, null) 是唯一手段，
     * 它把值置空但可能留下一行空记录 —— 想彻底清掉用：
     *   adb shell settings delete global hotspot_perm_probe
     */
    fun hasPermission(ctx: Context): Boolean = runCatching {
        Settings.Global.putInt(ctx.contentResolver, KEY_PROBE, 1)
        val ok = Settings.Global.getInt(ctx.contentResolver, KEY_PROBE, 0) == 1
        runCatching { Settings.Global.putString(ctx.contentResolver, KEY_PROBE, null) }
        ok
    }.getOrElse {
        Log.d(TAG, "没有 WRITE_SECURE_SETTINGS: ${it.message}")
        false
    }

    /** 当前是不是已经关掉了自动超时 */
    fun isDisabled(ctx: Context): Boolean = runCatching {
        Settings.Global.getInt(ctx.contentResolver, KEY_AOSP) == 0
    }.getOrDefault(false)

    /**
     * 关闭「无设备连接时自动关闭热点」。
     * @return 是否成功写入
     */
    fun disable(ctx: Context): Boolean {
        var ok = false
        KEYS_TRY.forEach { key ->
            runCatching {
                Settings.Global.putInt(ctx.contentResolver, key, 0)
                Log.i(TAG, "已写入 $key = 0")
                ok = true
            }.onFailure {
                Log.d(TAG, "写 $key 失败: ${it.message}")
            }
        }
        return ok
    }

    /**
     * 恢复系统默认行为。
     * disable() 写了四个键，这里必须全部写回 1，否则厂商私有键会一直停在 0。
     */
    fun enable(ctx: Context): Boolean {
        var ok = false
        KEYS_TRY.forEach { key ->
            runCatching {
                Settings.Global.putInt(ctx.contentResolver, key, 1)
                ok = true
            }.onFailure {
                Log.d(TAG, "恢复 $key 失败: ${it.message}")
            }
        }
        return ok
    }

    /** 给用户看的 adb 命令 */
    fun grantCommand(pkg: String) =
        "adb shell pm grant $pkg android.permission.WRITE_SECURE_SETTINGS"
}
