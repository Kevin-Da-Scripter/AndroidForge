package com.xin.hotspot.ui

import android.content.Context
import android.content.res.Configuration
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import java.util.Locale

/**
 * 界面语言。
 *
 * 为什么要有 App 内的语言开关：
 *  - Android 13+ 才有系统级的「按应用设置语言」（per-app locale）
 *  - 这台真机是 Android 12，没有该能力，只能自己实现
 *  - 顺带也方便验证两套 strings.xml 都正常
 */
enum class AppLanguage(val tag: String) {
    /** 跟随系统 */
    SYSTEM(""),
    ENGLISH("en"),
    CHINESE("zh"),
}

/** 当前语言，由 MainActivity 提供 */
val LocalAppLanguage = compositionLocalOf { AppLanguage.SYSTEM }

/**
 * 按选定语言重建 Context，让 stringResource() 取到对应的资源。
 *
 * 注意：必须同时覆盖 LocalContext 和 LocalConfiguration。
 * 只改 Configuration 不够 —— stringResource() 实际是从 LocalContext.resources 取的。
 */
@Composable
fun LocalizedContent(language: AppLanguage, content: @Composable () -> Unit) {
    if (language == AppLanguage.SYSTEM) {
        CompositionLocalProvider(LocalAppLanguage provides language, content = content)
        return
    }

    val ctx = LocalContext.current
    val config = Configuration(LocalConfiguration.current).apply {
        val locale = Locale.forLanguageTag(language.tag)
        setLocale(locale)
        setLayoutDirection(locale)
    }
    val localizedCtx: Context = ctx.createConfigurationContext(config)

    CompositionLocalProvider(
        LocalAppLanguage provides language,
        LocalContext provides localizedCtx,
        LocalConfiguration provides config,
        content = content
    )
}
