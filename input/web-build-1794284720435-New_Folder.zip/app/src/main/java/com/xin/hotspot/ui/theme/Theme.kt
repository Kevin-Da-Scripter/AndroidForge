package com.xin.hotspot.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// ── 深色 + 青绿辉光 ──────────────────────────────────
val Ink        = Color(0xFF07090C)   // 近黑背景（OLED 省电）
val Surface1   = Color(0xFF0E1318)   // 卡片底
val Surface2   = Color(0xFF161D24)   // 抬高的卡片
val Outline    = Color(0xFF232C36)

val Mint       = Color(0xFF2AF5C8)   // 主青绿 —— 运行中
val MintDim    = Color(0xFF128F76)
val MintGlow   = Color(0x332AF5C8)   // 辉光（20% alpha）

val Amber      = Color(0xFFFFC24B)   // 警告 —— 正在恢复
val Coral      = Color(0xFFFF6B6B)   // 危险 —— 已断开
val Sky        = Color(0xFF5AC8FA)   // 次要强调 —— 下行流量

val TextHi     = Color(0xFFF2F6FA)
val TextMid    = Color(0xFF93A3B4)
val TextLo     = Color(0xFF5B6977)

private val HotspotDark = darkColorScheme(
    primary = Mint,
    onPrimary = Ink,
    secondary = Sky,
    background = Ink,
    onBackground = TextHi,
    surface = Surface1,
    onSurface = TextHi,
    surfaceVariant = Surface2,
    onSurfaceVariant = TextMid,
    outline = Outline,
    error = Coral,
)

@Composable
fun HotspotTheme(content: @Composable () -> Unit) {
    // 这个 App 固定深色 —— 它要长时间开着，深色最省电也最好看
    MaterialTheme(colorScheme = HotspotDark, content = content)
}
