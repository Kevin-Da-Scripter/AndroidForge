package com.xin.hotspot.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.xin.hotspot.R
import com.xin.hotspot.data.HotspotState
import com.xin.hotspot.ui.theme.*

/**
 * 主界面的大圆环状态盘。
 * 运行中时青绿色 + 缓慢呼吸辉光；掉线时珊瑚红；恢复中时琥珀色 + 快速旋转。
 */
@Composable
fun StatusDial(
    state: HotspotState,
    uptimeMs: Long,
    clientCount: Int,
    modifier: Modifier = Modifier,
) {
    val accent = when (state) {
        HotspotState.ON -> Mint
        HotspotState.RECOVERING -> Amber
        HotspotState.OFF -> TextLo
        HotspotState.UNKNOWN -> TextLo
    }

    val infinite = rememberInfiniteTransition(label = "dial")

    // 运行中：缓慢呼吸（辉光强弱）
    val breath by infinite.animateFloat(
        initialValue = 0.55f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "breath"
    )

    // 恢复中：转圈
    val spin by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = LinearEasing)
        ),
        label = "spin"
    )

    val glowAlpha = if (state == HotspotState.ON) breath else 1f

    Box(
        modifier = modifier.size(260.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 14.dp.toPx()
            val inset = stroke / 2 + 18.dp.toPx()
            val arcSize = Size(size.width - inset * 2, size.height - inset * 2)
            val topLeft = Offset(inset, inset)

            // 外层辉光（多层递减，模拟发光）
            if (state != HotspotState.OFF) {
                for (i in 3 downTo 1) {
                    drawArc(
                        color = accent.copy(alpha = 0.05f * i * glowAlpha),
                        startAngle = -90f,
                        sweepAngle = 360f,
                        useCenter = false,
                        topLeft = Offset(inset - i * 6.dp.toPx(), inset - i * 6.dp.toPx()),
                        size = Size(
                            arcSize.width + i * 12.dp.toPx(),
                            arcSize.height + i * 12.dp.toPx()
                        ),
                        style = Stroke(width = stroke + i * 4.dp.toPx(), cap = StrokeCap.Round)
                    )
                }
            }

            // 轨道底色
            drawArc(
                color = Outline,
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = stroke, cap = StrokeCap.Round)
            )

            // 主圆环
            when (state) {
                HotspotState.ON -> {
                    drawArc(
                        brush = Brush.sweepGradient(
                            listOf(MintDim, Mint, Mint, MintDim)
                        ),
                        startAngle = -90f,
                        sweepAngle = 360f,
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(width = stroke, cap = StrokeCap.Round)
                    )
                }
                HotspotState.RECOVERING -> {
                    drawArc(
                        color = Amber,
                        startAngle = spin - 90f,
                        sweepAngle = 90f,
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(width = stroke, cap = StrokeCap.Round)
                    )
                }
                else -> {
                    drawArc(
                        color = TextLo.copy(alpha = 0.4f),
                        startAngle = -90f,
                        sweepAngle = 360f,
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(width = stroke, cap = StrokeCap.Round)
                    )
                }
            }
        }

        // 圆环中心的文字
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Canvas(Modifier.size(9.dp)) {
                    drawCircle(color = accent, alpha = glowAlpha)
                }
                Spacer(Modifier.width(7.dp))
                Text(
                    text = stringResource(
                        when (state) {
                            HotspotState.ON -> R.string.state_running
                            HotspotState.OFF -> R.string.state_off
                            HotspotState.RECOVERING -> R.string.state_recovering
                            HotspotState.UNKNOWN -> R.string.state_checking
                        }
                    ),
                    color = accent,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium,
                )
            }

            Spacer(Modifier.height(10.dp))

            Text(
                text = formatUptime(uptimeMs),
                color = TextHi,
                fontSize = 40.sp,
                fontWeight = FontWeight.Light,
                textAlign = TextAlign.Center,
            )

            Spacer(Modifier.height(4.dp))

            Text(
                text = stringResource(
                    if (state == HotspotState.ON) R.string.dial_stable
                    else R.string.dial_not_running
                ),
                color = TextLo,
                fontSize = 12.sp,
            )

            Spacer(Modifier.height(18.dp))

            Text(
                text = if (clientCount > 0)
                    pluralStringResource(R.plurals.dial_client_count, clientCount, clientCount)
                else stringResource(R.string.dial_no_clients),
                color = if (clientCount > 0) TextMid else TextLo,
                fontSize = 13.sp,
            )
        }
    }
}

fun formatUptime(ms: Long): String {
    if (ms <= 0) return "—"
    val totalMin = ms / 60_000
    val h = totalMin / 60
    val m = totalMin % 60
    return when {
        h > 0 -> "${h}h ${m}m"
        m > 0 -> "${m}m"
        else -> "${ms / 1000}s"
    }
}

/** 把字节数格式化成人看的样子。null 表示拿不到数据，如实显示。 */
fun formatBytes(b: Long?): String {
    if (b == null) return "—"
    val kb = 1024.0
    return when {
        b < kb -> "$b B"
        b < kb * kb -> String.format("%.0f KB", b / kb)
        b < kb * kb * kb -> String.format("%.1f MB", b / (kb * kb))
        else -> String.format("%.2f GB", b / (kb * kb * kb))
    }
}
