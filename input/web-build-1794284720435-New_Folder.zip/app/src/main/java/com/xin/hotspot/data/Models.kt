package com.xin.hotspot.data

/** 热点当前状态 */
enum class HotspotState {
    ON,          // 运行中
    OFF,         // 已关闭
    RECOVERING,  // 检测到掉线，正在自动恢复
    UNKNOWN
}

/** 一台连接到热点的客户端设备 */
data class ClientDevice(
    val mac: String,
    val ip: String,
    /** 自动识别出的名字（主机名 / MAC 厂商），可能为 null */
    val autoName: String?,
    /** 用户手动改的名字，优先级最高 */
    val customName: String? = null,
    /** 累计用量（字节）。拿不到时为 null —— 界面要如实显示"不可用"而不是编 0 */
    val totalBytes: Long? = null,
    /** 当前速率（字节/秒），拿不到时为 null */
    val rateBps: Long? = null,
    /** 最近一段时间的用量采样，用于画迷你条形图 */
    val sparkline: List<Float> = emptyList(),
    val isOnline: Boolean = true,
    val firstSeenAt: Long = 0L,
) {
    /**
     * 界面上显示的名字：手动名 > 自动名。
     * 都没有时返回 null —— 兜底名（"设备 xx.xxx"）需要本地化字符串，
     * 这里拿不到 Context，交给 UI 层用 R.string.device_fallback_name 渲染。
     */
    val displayName: String?
        get() = customName ?: autoName

    /** 猜测设备类型，用于选图标 */
    val kind: DeviceKind
        get() {
            val n = (customName ?: autoName ?: "").lowercase()
            return when {
                n.contains("iphone") || n.contains("phone") || n.contains("android") -> DeviceKind.PHONE
                n.contains("ipad") || n.contains("tab") -> DeviceKind.TABLET
                n.contains("book") || n.contains("mac") || n.contains("pc") ||
                    n.contains("laptop") || n.contains("desktop") -> DeviceKind.COMPUTER
                n.contains("tv") || n.contains("switch") || n.contains("cast") -> DeviceKind.TV
                else -> DeviceKind.UNKNOWN
            }
        }
}

enum class DeviceKind { PHONE, TABLET, COMPUTER, TV, UNKNOWN }

/** 一次状态变化事件，用于时间线 */
data class HotspotEvent(
    val at: Long,
    val type: EventType,
    val detail: String = "",
)

enum class EventType {
    STARTED,        // 热点开启
    STOPPED,        // 热点关闭（用户主动）
    DROPPED,        // 意外掉线
    RECOVERED,      // 自动恢复成功
    RECOVER_FAILED, // 自动恢复失败
    CLIENT_JOINED,
    CLIENT_LEFT,
}

/** 整个 App 的 UI 状态 */
data class HotspotUiState(
    val state: HotspotState = HotspotState.UNKNOWN,
    /** 本次连续运行时长（毫秒） */
    val uptimeMs: Long = 0L,
    val clients: List<ClientDevice> = emptyList(),
    val events: List<HotspotEvent> = emptyList(),
    /** 看门狗是否在运行 */
    val watchdogEnabled: Boolean = false,
    /** 是否已拿到 WRITE_SECURE_SETTINGS —— 决定能否关闭自动超时 */
    val hasSecureSettings: Boolean = false,
    /** 「无设备连接时自动关闭」是否已被关掉 */
    val idleTimeoutDisabled: Boolean = false,
    /** 本次会话总用量，拿不到为 null */
    val totalBytes: Long? = null,
    /** 累计自动恢复次数 */
    val recoveryCount: Int = 0,
)
