package com.xin.hotspot.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.xin.hotspot.R
import com.xin.hotspot.data.ClientDevice
import com.xin.hotspot.data.DeviceKind
import com.xin.hotspot.ui.theme.*

@Composable
fun DeviceRow(
    device: ClientDevice,
    onRename: (ClientDevice) -> Unit,
    modifier: Modifier = Modifier,
) {
    var showMenu by remember { mutableStateOf(false) }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Surface1)
            .clickable { onRename(device) }
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // 设备图标
        Box(
            Modifier
                .size(42.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(if (device.isOnline) MintGlow else Surface2),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = when (device.kind) {
                    DeviceKind.PHONE -> Icons.Default.Smartphone
                    DeviceKind.TABLET -> Icons.Default.Tablet
                    DeviceKind.COMPUTER -> Icons.Default.Laptop
                    DeviceKind.TV -> Icons.Default.Tv
                    DeviceKind.UNKNOWN -> Icons.Default.DeviceUnknown
                },
                contentDescription = null,
                tint = if (device.isOnline) Mint else TextLo,
                modifier = Modifier.size(21.dp)
            )
        }

        Spacer(Modifier.width(14.dp))

        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    device.displayName ?: stringResource(
                        R.string.device_fallback_name,
                        device.mac.takeLast(5).uppercase()
                    ),
                    color = TextHi,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                )
                if (device.customName == null) {
                    Spacer(Modifier.width(6.dp))
                    Icon(
                        Icons.Default.Edit,
                        contentDescription = stringResource(R.string.action_rename),
                        tint = TextLo,
                        modifier = Modifier.size(12.dp)
                    )
                }
            }
            Spacer(Modifier.height(3.dp))
            Text(
                text = device.ip,
                color = TextLo,
                fontSize = 11.sp,
            )
        }

        // 用量：拿不到就如实显示 "—"，不编数字
        Column(horizontalAlignment = Alignment.End) {
            Text(
                text = formatBytes(device.totalBytes),
                color = if (device.totalBytes != null) TextHi else TextLo,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
            )
            Spacer(Modifier.height(3.dp))
            if (device.rateBps != null && device.rateBps > 0) {
                Text(
                    text = stringResource(R.string.device_rate, formatBytes(device.rateBps)),
                    color = Sky,
                    fontSize = 11.sp,
                )
            } else {
                Text(
                    text = stringResource(
                        if (device.isOnline) R.string.device_online else R.string.device_offline
                    ),
                    color = if (device.isOnline) MintDim else TextLo,
                    fontSize = 11.sp,
                )
            }
        }
    }
}

/** 改名弹窗 */
@Composable
fun RenameDialog(
    device: ClientDevice,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit,
) {
    var text by remember { mutableStateOf(device.customName ?: device.autoName ?: "") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Surface2,
        title = {
            Text(stringResource(R.string.rename_title), color = TextHi, fontSize = 17.sp)
        },
        text = {
            Column {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    singleLine = true,
                    placeholder = {
                        Text(stringResource(R.string.rename_placeholder), color = TextLo)
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Mint,
                        unfocusedBorderColor = Outline,
                        focusedTextColor = TextHi,
                        unfocusedTextColor = TextHi,
                        cursorColor = Mint,
                    )
                )
                Spacer(Modifier.height(12.dp))
                Text(
                    stringResource(R.string.rename_ip, device.ip),
                    color = TextLo,
                    fontSize = 11.sp
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    stringResource(R.string.rename_warning),
                    color = Amber,
                    fontSize = 11.sp,
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(text) }) {
                Text(stringResource(R.string.action_save), color = Mint)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.action_cancel), color = TextMid)
            }
        }
    )
}
