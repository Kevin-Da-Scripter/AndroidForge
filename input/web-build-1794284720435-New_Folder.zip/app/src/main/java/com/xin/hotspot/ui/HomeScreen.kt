package com.xin.hotspot.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.xin.hotspot.R
import com.xin.hotspot.data.*
import com.xin.hotspot.ui.theme.*

@Composable
fun HomeScreen(
    state: HotspotUiState,
    onToggleWatchdog: (Boolean) -> Unit,
    onRenameDevice: (ClientDevice, String) -> Unit,
    onOpenHotspotSettings: () -> Unit,
    language: AppLanguage = AppLanguage.SYSTEM,
    onLanguageChange: (AppLanguage) -> Unit = {},
) {
    var renaming by remember { mutableStateOf<ClientDevice?>(null) }

    renaming?.let { dev ->
        RenameDialog(
            device = dev,
            onDismiss = { renaming = null },
            onConfirm = { newName ->
                onRenameDevice(dev, newName)
                renaming = null
            }
        )
    }

    LazyColumn(
        Modifier
            .fillMaxSize()
            .background(Ink)
            .statusBarsPadding(),
        contentPadding = PaddingValues(bottom = 32.dp)
    ) {
        // ── 语言切换 ──
        item {
            LanguageSwitch(
                current = language,
                onSelect = onLanguageChange,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp, end = 18.dp)
            )
        }

        // ── 顶部：大圆环 ──
        item {
            Box(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 28.dp, bottom = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                StatusDial(
                    state = state.state,
                    uptimeMs = state.uptimeMs,
                    clientCount = state.clients.count { it.isOnline },
                )
            }
        }

        // ── 守护开关 ──
        item {
            WatchdogCard(
                enabled = state.watchdogEnabled,
                hasPermission = state.hasSecureSettings,
                idleTimeoutDisabled = state.idleTimeoutDisabled,
                recoveryCount = state.recoveryCount,
                onToggle = onToggleWatchdog,
                modifier = Modifier.padding(horizontal = 18.dp, vertical = 6.dp)
            )
        }

        // ── 总用量 ──
        item {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 18.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatTile(
                    stringResource(R.string.stat_total_traffic),
                    formatBytes(state.totalBytes), Sky, Modifier.weight(1f)
                )
                StatTile(
                    stringResource(R.string.stat_drop_count),
                    stringResource(R.string.stat_drop_value, state.recoveryCount),
                    Amber, Modifier.weight(1f)
                )
            }
        }

        // ── 设备列表标题 ──
        item {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(start = 22.dp, end = 22.dp, top = 22.dp, bottom = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    stringResource(R.string.devices_title),
                    color = TextHi, fontSize = 16.sp, fontWeight = FontWeight.SemiBold
                )
                Text(
                    stringResource(R.string.devices_count, state.clients.count { it.isOnline }),
                    color = TextLo, fontSize = 13.sp
                )
            }
        }

        if (state.clients.isEmpty()) {
            item {
                EmptyDevices(
                    hotspotOn = state.state == HotspotState.ON,
                    onOpenSettings = onOpenHotspotSettings,
                    modifier = Modifier.padding(horizontal = 18.dp)
                )
            }
        } else {
            items(state.clients, key = { it.mac }) { dev ->
                DeviceRow(
                    device = dev,
                    onRename = { renaming = it },
                    modifier = Modifier.padding(horizontal = 18.dp, vertical = 4.dp)
                )
            }
        }

        // ── 事件时间线 ──
        if (state.events.isNotEmpty()) {
            item {
                Text(
                    stringResource(R.string.events_title),
                    color = TextHi, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(start = 22.dp, top = 26.dp, bottom = 10.dp)
                )
            }
            items(state.events.take(12)) { ev ->
                EventRow(ev, Modifier.padding(horizontal = 22.dp, vertical = 5.dp))
            }
        }
    }
}

@Composable
private fun LanguageSwitch(
    current: AppLanguage,
    onSelect: (AppLanguage) -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(modifier, horizontalArrangement = Arrangement.End) {
        Row(
            Modifier
                .clip(RoundedCornerShape(9.dp))
                .background(Surface1)
                .padding(3.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            listOf(
                AppLanguage.SYSTEM to R.string.language_system,
                AppLanguage.ENGLISH to R.string.language_english,
                AppLanguage.CHINESE to R.string.language_chinese,
            ).forEach { (lang, labelRes) ->
                val active = lang == current
                Text(
                    text = stringResource(labelRes),
                    color = if (active) Ink else TextLo,
                    fontSize = 11.sp,
                    fontWeight = if (active) FontWeight.Medium else FontWeight.Normal,
                    modifier = Modifier
                        .clip(RoundedCornerShape(7.dp))
                        .background(if (active) Mint else Surface1)
                        .clickable { onSelect(lang) }
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                )
            }
        }
    }
}

@Composable
private fun WatchdogCard(
    enabled: Boolean,
    hasPermission: Boolean,
    idleTimeoutDisabled: Boolean,
    recoveryCount: Int,
    onToggle: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
) {
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(Surface1)
            .padding(18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                Icons.Default.Shield,
                contentDescription = null,
                tint = if (enabled) Mint else TextLo,
                modifier = Modifier.size(20.dp)
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    stringResource(R.string.watchdog_title),
                    color = TextHi, fontSize = 15.sp, fontWeight = FontWeight.Medium
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    stringResource(
                        if (enabled) R.string.watchdog_on_subtitle
                        else R.string.watchdog_off_subtitle
                    ),
                    color = TextLo, fontSize = 11.sp
                )
            }
            Switch(
                checked = enabled,
                onCheckedChange = onToggle,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Ink,
                    checkedTrackColor = Mint,
                    uncheckedThumbColor = TextLo,
                    uncheckedTrackColor = Surface2,
                )
            )
        }

        // 权限状态提示 —— 诚实告诉用户当前能做到什么
        Spacer(Modifier.height(14.dp))
        Divider(color = Outline, thickness = 1.dp)
        Spacer(Modifier.height(12.dp))

        CapabilityLine(
            ok = idleTimeoutDisabled,
            okText = stringResource(R.string.cap_idle_off_ok),
            failText = stringResource(R.string.cap_idle_off_fail),
        )
        Spacer(Modifier.height(7.dp))
        CapabilityLine(
            ok = true,
            okText = stringResource(R.string.cap_notify_ok),
            failText = "",
        )

        if (!hasPermission) {
            Spacer(Modifier.height(12.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(Amber.copy(alpha = 0.10f))
                    .padding(12.dp)
            ) {
                Column {
                    Text(
                        stringResource(R.string.grant_title),
                        color = Amber, fontSize = 12.sp, fontWeight = FontWeight.Medium
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        stringResource(R.string.grant_command),
                        color = TextMid, fontSize = 10.sp,
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        stringResource(R.string.grant_note),
                        color = TextLo, fontSize = 10.sp,
                    )
                }
            }
        }
    }
}

@Composable
private fun CapabilityLine(ok: Boolean, okText: String, failText: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
            if (ok) Icons.Default.CheckCircle else Icons.Default.Info,
            contentDescription = null,
            tint = if (ok) Mint else Amber,
            modifier = Modifier.size(14.dp)
        )
        Spacer(Modifier.width(8.dp))
        Text(
            if (ok) okText else failText,
            color = if (ok) TextMid else Amber,
            fontSize = 12.sp
        )
    }
}

@Composable
private fun StatTile(label: String, value: String, accent: androidx.compose.ui.graphics.Color, modifier: Modifier = Modifier) {
    Column(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Surface1)
            .padding(16.dp)
    ) {
        Text(label, color = TextLo, fontSize = 11.sp)
        Spacer(Modifier.height(6.dp))
        Text(value, color = accent, fontSize = 22.sp, fontWeight = FontWeight.Light)
    }
}

@Composable
private fun EmptyDevices(hotspotOn: Boolean, onOpenSettings: () -> Unit, modifier: Modifier = Modifier) {
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Surface1)
            .clickable(enabled = !hotspotOn) { onOpenSettings() }
            .padding(vertical = 30.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            if (hotspotOn) Icons.Default.WifiTethering else Icons.Default.WifiTetheringOff,
            contentDescription = null,
            tint = TextLo,
            modifier = Modifier.size(30.dp)
        )
        Spacer(Modifier.height(12.dp))
        Text(
            stringResource(
                if (hotspotOn) R.string.empty_hotspot_on else R.string.empty_hotspot_off
            ),
            color = TextMid, fontSize = 13.sp
        )
        if (!hotspotOn) {
            Spacer(Modifier.height(6.dp))
            Text(stringResource(R.string.empty_tap_to_open), color = Mint, fontSize = 12.sp)
        }
    }
}

@Composable
private fun EventRow(ev: HotspotEvent, modifier: Modifier = Modifier) {
    val (icon, tint, labelRes) = when (ev.type) {
        EventType.STARTED -> Triple(Icons.Default.PlayArrow, Mint, R.string.event_started)
        EventType.STOPPED -> Triple(Icons.Default.Stop, TextLo, R.string.event_stopped)
        EventType.DROPPED -> Triple(Icons.Default.Warning, Coral, R.string.event_dropped)
        EventType.RECOVERED -> Triple(Icons.Default.Restore, Mint, R.string.event_recovered)
        EventType.RECOVER_FAILED -> Triple(Icons.Default.ErrorOutline, Coral, R.string.event_recover_failed)
        EventType.CLIENT_JOINED -> Triple(Icons.Default.Add, Sky, R.string.event_client_joined)
        EventType.CLIENT_LEFT -> Triple(Icons.Default.Remove, TextLo, R.string.event_client_left)
    }
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(14.dp))
        Spacer(Modifier.width(10.dp))
        Text(
            stringResource(labelRes),
            color = TextMid, fontSize = 12.sp, modifier = Modifier.weight(1f)
        )
        if (ev.detail.isNotEmpty()) {
            Text(ev.detail, color = TextLo, fontSize = 11.sp)
            Spacer(Modifier.width(8.dp))
        }
        Text(
            android.text.format.DateFormat.format("HH:mm", ev.at).toString(),
            color = TextLo, fontSize = 11.sp
        )
    }
}
