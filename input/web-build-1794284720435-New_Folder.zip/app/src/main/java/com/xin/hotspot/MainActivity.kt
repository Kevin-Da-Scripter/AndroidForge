package com.xin.hotspot

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.xin.hotspot.data.*
import com.xin.hotspot.service.HotspotWatchdogService
import com.xin.hotspot.ui.HomeScreen
import com.xin.hotspot.ui.LocalizedContent
import com.xin.hotspot.ui.theme.HotspotTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val notifPermLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* 用户拒绝也不阻塞，只是通知栏体验差些 */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        HotspotRepository.init(this)
        requestNotificationPermission()

        // 如果有权限，进来就把「没人连自动关」关掉 —— 这是用户的核心诉求
        if (IdleTimeoutController.hasPermission(this)) {
            val ok = IdleTimeoutController.disable(this)
            HotspotRepository.setIdleTimeoutDisabled(ok)
        }

        // 状态轮询：每秒刷运行时长，每 10 秒重扫一次客户端
        lifecycleScope.launch {
            var baselineBytes = 0L
            var tick = 0
            while (true) {
                val ap = HotspotProbe.findActiveAp()
                HotspotRepository.setHotspotState(
                    if (ap != null) HotspotState.ON else HotspotState.OFF
                )
                HotspotRepository.tickUptime()

                if (ap != null) {
                    // 流量基线（整机计数的增量）
                    val now = HotspotProbe.totalBytes()
                    if (baselineBytes == 0L) baselineBytes = now
                    HotspotRepository.setSessionBytes(now - baselineBytes)

                    // 每 10 秒扫一次设备（扫描本身要 1-2 秒，别太频繁）
                    if (tick % 10 == 0) {
                        launch {
                            val clients = HotspotProbe.scanClients(ap.localIp)
                            HotspotRepository.updateClients(clients)
                        }
                    }
                } else {
                    baselineBytes = 0L
                }

                tick++
                delay(1000)
            }
        }

        setContent {
            HotspotTheme {
                val state by HotspotRepository.state.collectAsState()
                var language by remember {
                    mutableStateOf(HotspotRepository.getLanguage())
                }
                LocalizedContent(language) {
                    HomeScreen(
                        state = state,
                        onToggleWatchdog = { on ->
                            HotspotRepository.setWatchdog(on)
                            if (on) HotspotWatchdogService.start(this)
                            else HotspotWatchdogService.stop(this)
                        },
                        onRenameDevice = { dev, name ->
                            HotspotRepository.setCustomName(dev.mac, name)
                        },
                        onOpenHotspotSettings = { openHotspotSettings() },
                        language = language,
                        onLanguageChange = {
                            language = it
                            HotspotRepository.setLanguage(it)
                        },
                    )
                }
            }
        }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    /** 跳到系统的热点设置页 —— App 无法直接开热点，只能带用户过去 */
    private fun openHotspotSettings() {
        val candidates = listOf(
            Intent().setClassName(
                "com.android.settings",
                "com.android.settings.TetherSettings"
            ),
            Intent(Settings.ACTION_WIRELESS_SETTINGS),
            Intent(Settings.ACTION_SETTINGS),
        )
        for (i in candidates) {
            if (runCatching { startActivity(i); true }.getOrDefault(false)) return
        }
    }
}
