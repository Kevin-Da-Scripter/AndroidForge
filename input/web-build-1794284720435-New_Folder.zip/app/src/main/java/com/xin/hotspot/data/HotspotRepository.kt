package com.xin.hotspot.data

import android.content.Context
import android.content.SharedPreferences
import com.xin.hotspot.ui.AppLanguage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * 全局状态仓库。单例，Service 和 UI 共享同一份状态。
 */
object HotspotRepository {

    private val _state = MutableStateFlow(HotspotUiState())
    val state: StateFlow<HotspotUiState> = _state.asStateFlow()

    private var prefs: SharedPreferences? = null
    private var sessionStartAt = 0L

    /** MAC -> 用户自定义名字 */
    private val customNames = mutableMapOf<String, String>()

    fun init(ctx: Context) {
        prefs = ctx.getSharedPreferences("hotspot", Context.MODE_PRIVATE)
        loadNames()
        _state.value = _state.value.copy(
            hasSecureSettings = IdleTimeoutController.hasPermission(ctx),
            idleTimeoutDisabled = IdleTimeoutController.isDisabled(ctx),
        )
    }

    private fun loadNames() {
        prefs?.all?.forEach { (k, v) ->
            if (k.startsWith("name_") && v is String) {
                customNames[k.removePrefix("name_")] = v
            }
        }
    }

    fun setCustomName(mac: String, name: String) {
        if (name.isBlank()) {
            customNames.remove(mac)
            prefs?.edit()?.remove("name_$mac")?.apply()
        } else {
            customNames[mac] = name
            prefs?.edit()?.putString("name_$mac", name)?.apply()
        }
        // 立刻刷新界面
        _state.value = _state.value.copy(
            clients = _state.value.clients.map {
                if (it.mac == mac) it.copy(customName = customNames[mac]) else it
            }
        )
    }

    fun updateClients(fresh: List<ClientDevice>) {
        val now = System.currentTimeMillis()
        val existing = _state.value.clients.associateBy { it.mac }
        val freshMacs = fresh.map { it.mac }.toSet()

        val merged = fresh.map { d ->
            val old = existing[d.mac]
            d.copy(
                customName = customNames[d.mac],
                firstSeenAt = old?.firstSeenAt ?: now,
                totalBytes = old?.totalBytes,   // 逐设备用量还没实现，保持 null
                isOnline = true,
            )
        } + existing.values.filter { it.mac !in freshMacs }.map { it.copy(isOnline = false) }

        _state.value = _state.value.copy(clients = merged)
    }

    fun setHotspotState(s: HotspotState) {
        if (s == HotspotState.ON && sessionStartAt == 0L) {
            sessionStartAt = System.currentTimeMillis()
        } else if (s != HotspotState.ON) {
            sessionStartAt = 0L
        }
        _state.value = _state.value.copy(
            state = s,
            uptimeMs = if (sessionStartAt > 0) System.currentTimeMillis() - sessionStartAt else 0L
        )
    }

    fun tickUptime() {
        if (sessionStartAt > 0) {
            _state.value = _state.value.copy(
                uptimeMs = System.currentTimeMillis() - sessionStartAt
            )
        }
    }

    /** 设置本次会话的流量增量（整机计数差值） */
    fun setSessionBytes(bytes: Long) {
        _state.value = _state.value.copy(totalBytes = if (bytes >= 0) bytes else 0L)
    }

    fun recordEvent(type: EventType, detail: String = "") {
        val ev = HotspotEvent(System.currentTimeMillis(), type, detail)
        val updated = (listOf(ev) + _state.value.events).take(50)
        val recoveries = if (type == EventType.DROPPED)
            _state.value.recoveryCount + 1 else _state.value.recoveryCount
        _state.value = _state.value.copy(events = updated, recoveryCount = recoveries)
    }

    fun setWatchdog(on: Boolean) {
        _state.value = _state.value.copy(watchdogEnabled = on)
    }

    fun setIdleTimeoutDisabled(v: Boolean) {
        _state.value = _state.value.copy(idleTimeoutDisabled = v)
    }

    /** 界面语言偏好 —— Android 12 没有系统级 per-app locale，只能自己存 */
    fun getLanguage(): AppLanguage {
        val tag = prefs?.getString("ui_language", null) ?: return AppLanguage.SYSTEM
        return AppLanguage.entries.firstOrNull { it.name == tag } ?: AppLanguage.SYSTEM
    }

    fun setLanguage(lang: AppLanguage) {
        prefs?.edit()?.putString("ui_language", lang.name)?.apply()
    }

    fun uptimeText(): String {
        val ms = if (sessionStartAt > 0) System.currentTimeMillis() - sessionStartAt else 0L
        val min = ms / 60000
        return if (min >= 60) "${min / 60}h${min % 60}m" else "${min}m"
    }
}
