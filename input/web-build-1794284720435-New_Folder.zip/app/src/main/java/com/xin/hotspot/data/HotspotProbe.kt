package com.xin.hotspot.data

import android.net.TrafficStats
import android.util.Log
import kotlinx.coroutines.*
import java.net.Inet4Address
import java.net.InetAddress
import java.net.NetworkInterface

/**
 * 热点探测 —— 第三版，基于真机实测重写。
 *
 * ⚠️ 实测结论（JLN-AL00 / EMUI 14 / Android 12）：
 *   1. 华为热点接口是 p2p0，不是 AOSP 的 wlan1/ap0/softap0！
 *      31: p2p0  inet 192.168.43.1/24  →  dumpsys tethering 确认 TetheredState
 *   2. App 身份（untrusted_app）读不到任何 /proc/net/ 和 /sys/class/net/ 下的文件
 *   3. java.net.NetworkInterface 可用（走 netlink，不读文件）
 *   4. App 在 3003(inet) 组，可以开 socket 主动扫描
 */
object HotspotProbe {

    private const val TAG = "HotspotProbe"

    /**
     * 热点接口名模式。
     * p2p0 放第一个 —— 实测华为用它。其余是其他厂商/AOSP 的常见命名，做兼容。
     */
    private val AP_PATTERNS = listOf(
        Regex("^p2p\\d+$"),          // ← 华为实测命中
        Regex("^wlan[1-9]$"),
        Regex("^ap\\d*$"),
        Regex("^softap\\d*$"),
        Regex("^ap_br_wlan\\d+$"),
    )

    /** 热点分配的网段（dumpsys tethering 的 legacyDhcpRanges: 192.168.42~50.x）*/
    private fun isTetherSubnet(ip: String): Boolean {
        val p = ip.split('.')
        if (p.size != 4 || p[0] != "192" || p[1] != "168") return false
        val third = p[2].toIntOrNull() ?: return false
        return third in 42..50
    }

    data class ApInfo(val iface: String, val localIp: String)

    /**
     * 找当前活跃的热点接口。
     *
     * 判据（两个都要满足，避免误判）：
     *   a) 接口名匹配 AP 模式
     *   b) 有一个 192.168.4x.x 的 IPv4 地址
     * 光看接口存在不够 —— p2p0 在热点关闭时依然存在，只是没有 IPv4 地址。
     */
    suspend fun findActiveAp(): ApInfo? = withContext(Dispatchers.IO) {
        runCatching {
            val ifaces = NetworkInterface.getNetworkInterfaces() ?: return@runCatching null
            for (ni in ifaces) {
                val name = ni.name ?: continue
                if (!AP_PATTERNS.any { it.matches(name) }) continue

                for (addr in ni.inetAddresses) {
                    if (addr !is Inet4Address) continue
                    val ip = addr.hostAddress ?: continue
                    if (isTetherSubnet(ip)) {
                        Log.i(TAG, "热点接口: $name @ $ip")
                        return@runCatching ApInfo(name, ip)
                    }
                }
            }
            null
        }.getOrElse {
            Log.w(TAG, "枚举接口失败: ${it.message}")
            null
        }
    }

    /**
     * 主动扫描客户端设备。
     *
     * 只能拿到 IP —— MAC 和主机名都拿不到（/proc/net/arp 被 SELinux 挡）。
     * 所以设备身份用 IP 作为 key，配合用户手动命名。
     *
     * 并发 253 个探测，每个 600ms 超时，整体约 1-2 秒完成。
     */
    suspend fun scanClients(localIp: String): List<ClientDevice> = coroutineScope {
        val prefix = localIp.substringBeforeLast('.')
        Log.i(TAG, "开始扫描 $prefix.0/24")

        val results = (2..254).map { host ->
            async(Dispatchers.IO) {
                val ip = "$prefix.$host"
                if (ip == localIp) return@async null
                runCatching {
                    val addr = InetAddress.getByName(ip)
                    // isReachable 优先用 ICMP，失败会退化到 TCP:7
                    if (addr.isReachable(600)) {
                        ClientDevice(
                            mac = ip,               // 拿不到 MAC，用 IP 当唯一键
                            ip = ip,
                            autoName = null,        // 主机名基本也拿不到
                        )
                    } else null
                }.getOrNull()
            }
        }.awaitAll().filterNotNull()

        Log.i(TAG, "扫描完成，发现 ${results.size} 台设备")
        results
    }

    /**
     * 总流量。
     *
     * TrafficStats 是公开 API，App 可调。但它统计的是**整机**收发，
     * 无法分离出"热点转发"那部分，更无法按客户端拆分。
     *
     * 实测：dumpsys tethering 的 BPF 统计表返回 EBADF（损坏），
     * 所以逐设备流量在此设备上无解。这里只提供整机基线，
     * 由调用方做差值计算得到"本次会话增量"。
     */
    fun totalBytes(): Long {
        val rx = TrafficStats.getTotalRxBytes()
        val tx = TrafficStats.getTotalTxBytes()
        return if (rx == TrafficStats.UNSUPPORTED.toLong() ||
            tx == TrafficStats.UNSUPPORTED.toLong()
        ) 0L else rx + tx
    }

    /**
     * 移动数据流量 —— 如果上行是移动网络，这个比整机总量更接近"热点用掉的量"。
     * 实测当时上行是 wlan0（手机连着WiFi），所以这个值不动。
     */
    fun mobileBytes(): Long {
        val rx = TrafficStats.getMobileRxBytes()
        val tx = TrafficStats.getMobileTxBytes()
        return if (rx < 0 || tx < 0) 0L else rx + tx
    }
}
