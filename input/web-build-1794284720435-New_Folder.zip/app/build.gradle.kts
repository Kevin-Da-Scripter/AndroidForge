plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.xin.hotspot"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.xin.hotspot"
        // 目标机 JLN-AL00 是 Android 12 / SDK 31，minSdk 必须 <= 31
        minSdk = 29
        targetSdk = 34
        versionCode = 1
        versionName = "0.1"
    }

    // 发布签名从 ~/.gradle/gradle.properties 或环境变量读，仓库里不放任何密钥。
    // 没配置时 release 产出未签名 APK —— 绝不回退到 debug 签名：
    // debug keystore 的密码是公开的 android/androiddebugkey，谁都能伪造同签名包覆盖安装。
    val storeFilePath = findProperty("HOTSPOT_STORE_FILE") as String?

    signingConfigs {
        if (storeFilePath != null) {
            create("release") {
                storeFile = file(storeFilePath)
                storePassword = findProperty("HOTSPOT_STORE_PASSWORD") as String?
                keyAlias = findProperty("HOTSPOT_KEY_ALIAS") as String?
                keyPassword = findProperty("HOTSPOT_KEY_PASSWORD") as String?
            }
        }
    }

    buildTypes {
        debug {
            isMinifyEnabled = false
        }
        release {
            isMinifyEnabled = false
            signingConfig = if (storeFilePath != null)
                signingConfigs.getByName("release") else null
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }
}

// 固定编译用的 JDK，别人用 JDK 21/24 克隆也能直接构建
kotlin {
    jvmToolchain(17)
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.12.01")
    implementation(composeBom)

    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.activity:activity-compose:1.9.3")

    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.compose.ui:ui-tooling-preview")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
